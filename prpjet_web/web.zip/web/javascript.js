const canvas = document.getElementById("myCanvas");
const ctx = canvas.getContext('2d');
const POINT_SIZE = 10;
const COLS = 80;
const ROWS = 59;
const TICK_MS = 100;
const WINNING_SCORE = 3;

let grid = [];
let players = [];
let gameInterval = null;
let isGameRunning = false;
let isRoundActive = false;

const START_POSITIONS = {
  player1: { x: 1, y: 28 }, 
  player2: { x: 1, y: 30 } 
};

let keyBindings = {
  player1: { left: "Q", down: "W", right: "D", up: "Z", jump: "A" },
  player2: { left: "O", down: "K", right: ";", up: "M", jump: "P" }
};
function initPlayers() {
  players = [
    {
      x: START_POSITIONS.player1.x,
      y: START_POSITIONS.player1.y,
      dir: "RIGHT",
      alive: true,
      color: "blue",
      score: 0,
      dirQueue: [],
      canJump: true
    },
    {
      x: START_POSITIONS.player2.x,
      y: START_POSITIONS.player2.y,
      dir: "RIGHT",
      alive: true,
      color: "red",
      score: 0,
      dirQueue: [],
      canJump: true
    }
  ];
}
function initGrid() {
  grid = [];
  for (let x = 0; x < COLS; x += 1) {
    grid[x] = [];
    for (let y = 0; y < ROWS; y += 1) {
      grid[x][y] = -1;
    }
  }
  }
  function drawGrid() {
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  function drawPlayers() {
    for (let x = 0; x < COLS; x += 1) {
      for (let y = 0; y < ROWS; y += 1) {
        if (grid[x][y] !== -1) {
          const playerIndex = grid[x][y];

          if (players[playerIndex].alive && players[playerIndex].x === x && players[playerIndex].y === y) {
            continue;  
          }
          ctx.fillStyle = players[playerIndex].color;
          ctx.fillRect(x * POINT_SIZE, y * POINT_SIZE, POINT_SIZE, POINT_SIZE);
        }
      }
    }
    players.forEach(p => {
      if (!p.alive) return;
      const hasTrailOtherThanHead = grid.some((col, x) =>
        col.some((cell, y) => cell === players.indexOf(p) && !(p.x === x && p.y === y))
      );
  
      if (!hasTrailOtherThanHead) {
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x * POINT_SIZE, p.y * POINT_SIZE, POINT_SIZE, POINT_SIZE);
      } else {
        drawHead(p);
      }
    });
  }
  function drawHead(player) {
    const cx = player.x * POINT_SIZE + POINT_SIZE / 2;
    const cy = player.y * POINT_SIZE + POINT_SIZE / 2;
    const r = POINT_SIZE / 2;
  
    ctx.fillStyle = player.color;
    ctx.beginPath();
  
    let start = 0;
    let end = Math.PI;
  
    switch (player.dir) {
      case "RIGHT":
        start = -Math.PI / 2; 
        end = Math.PI / 2;
        break;
      case "LEFT":
        start = Math.PI / 2; 
        end = 3 * Math.PI / 2;
        break;
      case "UP":
        start = Math.PI;      
        end = 2 * Math.PI;   
        break;
      case "DOWN":
        start = 0; 
        end = Math.PI;
        break;
      default:
        start = -Math.PI / 2; 
        end = Math.PI / 2;
    }
  
    ctx.arc(cx, cy, r, start, end);
    ctx.lineTo(cx, cy);
    ctx.fill();
  }

  document.addEventListener("keydown", function (ev) {
    if (!isRoundActive) return;
  
    const key = ev.key.toUpperCase();
  
    handlePlayerInput(0, key);
    handlePlayerInput(1, key);
  });
  
  function handlePlayerInput(playerIndex, key) {
    const player = players[playerIndex];
    if (!player || !player.alive) return;
  
    const keys = playerIndex === 0 ? keyBindings.player1 : keyBindings.player2;
  
    let newDir = null;
    let isJump = false;
  
    if (key === keys.left.toUpperCase()) newDir = "LEFT";
    else if (key === keys.right.toUpperCase()) newDir = "RIGHT";
    else if (key === keys.up.toUpperCase()) newDir = "UP";
    else if (key === keys.down.toUpperCase()) newDir = "DOWN";
    else if (key === keys.jump.toUpperCase()) isJump = true;
  
    if (isJump) {
      if (player.canJump) {
        if (!player.dirQueue.some(a => a && a.type === "JUMP")) {
          player.dirQueue.push({ type: "JUMP" });
        }
      }
      return;
    }
  
    if (newDir) {
      const opposites = { LEFT: "RIGHT", RIGHT: "LEFT", UP: "DOWN", DOWN: "UP" };
      const lastDir = player.dirQueue.length > 0
        ? (player.dirQueue[player.dirQueue.length - 1].dir || player.dir)
        : player.dir;
  
      if (newDir !== opposites[lastDir]) {
        
        if (player.dirQueue.length < 5) {
          player.dirQueue.push({ type: "MOVE", dir: newDir });
        }
      }
    }
  }
  function peekNext(player, action) {
    let dir = player.dir;
    if (action && action.type === "MOVE" && action.dir) dir = action.dir;
  
    let nx = player.x, ny = player.y;
    switch (dir) {
      case "LEFT": nx -= 1; break;
      case "RIGHT": nx += 1; break;
      case "UP": ny -= 1; break;
      case "DOWN": ny += 1; break;
    }
    return { x: nx, y: ny, dir: dir };
  }
  
  function willCollide(x, y) {
    if (x < 0 || x >= COLS || y < 0 || y >= ROWS) return true;
    if (grid[x][y] !== -1) return true;
    return false;
  }
  
  function movePlayer(playerIndex) {
    const player = players[playerIndex];
    if (!player.alive) return;
    let nextAction = { type: "MOVE", dir: player.dir };
    if (player.dirQueue.length > 0) {
      nextAction = player.dirQueue.shift();
      if (nextAction.type === "MOVE") {
        player.dir = nextAction.dir;
      }
    }
    let nx = player.x;
    let ny = player.y;
    switch (player.dir) {
      case "LEFT": nx -= 1; break;
      case "RIGHT": nx += 1; break;
      case "UP": ny -= 1; break;
      case "DOWN": ny += 1; break;
    }
    if (nextAction.type === "JUMP" && player.canJump) {
      let midX = nx;
      let midY = ny;
      switch (player.dir) {
        case "LEFT": midX -= 1; break;
        case "RIGHT": midX += 1; break;
        case "UP": midY -= 1; break;
        case "DOWN": midY += 1; break;
      }
      if (willCollide(midX, midY)) {
        player.alive = false;
        return;
      }
      nx = midX; ny = midY;
      player.canJump = false; 
    }
    if (willCollide(nx, ny)) {
      player.alive = false;
      return;
    }
    player.x = nx;
    player.y = ny;
    grid[nx][ny] = playerIndex;
  }
  function gameTick() {
    if (!isRoundActive) return;
    const nexts = players.map((p, idx) => {
      if (!p.alive) return { x: p.x, y: p.y, idx: idx, alive: false };
      let peekAction = { type: "MOVE", dir: p.dir };
      if (p.dirQueue.length > 0) {
        peekAction = p.dirQueue[0];
      }
      const peek = peekNext(p, peekAction);
      if (peekAction.type === "JUMP" && p.canJump) {
        let nx = peek.x, ny = peek.y;
        switch (peek.dir) {
          case "LEFT": nx -= 1; break;
          case "RIGHT": nx += 1; break;
          case "UP": ny -= 1; break;
          case "DOWN": ny += 1; break;
        }
        return { x: nx, y: ny, idx: idx, action: peekAction };
      }
      return { x: peek.x, y: peek.y, idx: idx, action: peekAction };
    });
    if (nexts[0].x === nexts[1].x && nexts[0].y === nexts[1].y) {
      players[0].alive = false;
      players[1].alive = false;
    } else {
      movePlayer(0);
      movePlayer(1);
    }
    players.forEach((p, idx) => {
    if (!p.alive) {
      grid[p.x][p.y] = -1;
    }
  });
    const p1Dead = !players[0].alive;
    const p2Dead = !players[1].alive;
  
    if (p1Dead && p2Dead) {
      endRound(true);
    } else if (p1Dead) {
      players[1].score += 1;
      updateScoreHTML();
      endRound(false);
    } else if (p2Dead) {
      players[0].score += 1;
      updateScoreHTML();
      endRound(false);
    } else {
      drawGrid();
      drawPlayers();
    }
  }
  
  function endRound(isTie) {
    clearInterval(gameInterval);
    isRoundActive = false;

    setTimeout(() => {
      if (players[0].score >= WINNING_SCORE) {
        alert("Le joueur 1 (Bleu) a gagné la partie !");
        endGame();
        return;
      } else if (players[1].score >= WINNING_SCORE) {
        alert("Le joueur 2 (Rouge) a gagné la partie !");
        endGame();
        return;
      }
      startRound();
    }, 400); }
  
  function startGame() {
    if (isGameRunning) return;
    isGameRunning = true;
    document.getElementById("startBtn").disabled = true;
    document.getElementById("startBtn").textContent = "Partie en cours...";

    initPlayers();
    updateScoreHTML();
    startRound();
  }
  
  function startRound() {
    initGrid();
    players[0].x = START_POSITIONS.player1.x;
    players[0].y = START_POSITIONS.player1.y;
    players[0].alive = true;
    players[0].dir = "RIGHT";
    players[0].dirQueue = [];
    players[0].canJump = true;
  
    players[1].x = START_POSITIONS.player2.x;
    players[1].y = START_POSITIONS.player2.y;
    players[1].alive = true;
    players[1].dir = "RIGHT";
    players[1].dirQueue = [];
    players[1].canJump = true;
    grid[players[0].x][players[0].y] = 0;
    grid[players[1].x][players[1].y] = 1;
  
    isRoundActive = true;
    drawGrid();
    drawPlayers();
    gameInterval = setInterval(gameTick, TICK_MS);
  }
  
  function endGame() {
    isGameRunning = false;
    isRoundActive = false;
    clearInterval(gameInterval);
    document.getElementById("startBtn").disabled = false;
    document.getElementById("startBtn").textContent = "Démarrer la partie";
  }
  
  function updateScoreHTML() {
    document.getElementById("scorePlayer1").textContent = `Joueur 1 (Bleu): ${players[0].score}`;
    document.getElementById("scorePlayer2").textContent = `Joueur 2 (Rouge): ${players[1].score}`;
  }
  function openConfigDialog() {
    document.getElementById("p1Left").value = keyBindings.player1.left;
    document.getElementById("p1Up").value = keyBindings.player1.up;
    document.getElementById("p1Right").value = keyBindings.player1.right;
    document.getElementById("p1Down").value = keyBindings.player1.down;
    document.getElementById("p1Jump").value = keyBindings.player1.jump;
  
    document.getElementById("p2Left").value = keyBindings.player2.left;
    document.getElementById("p2Up").value = keyBindings.player2.up;
    document.getElementById("p2Right").value = keyBindings.player2.right;
    document.getElementById("p2Down").value = keyBindings.player2.down;
    document.getElementById("p2Jump").value = keyBindings.player2.jump;
  
    if (typeof $ !== "undefined" && $.ui) {
      $("#configDialog").dialog("open");
    } else {
      document.getElementById("configDialog").style.display = "block";
    }
  }
  function setupConfigInputs() {
    const inputs = document.querySelectorAll("#configDialog input");
    inputs.forEach(input => {
      input.addEventListener("click", function () {
        this.value = "...";
        this.focus();
        const self = this;
        const listener = function (e) {
          e.preventDefault();
          const key = e.key.toUpperCase();
          self.value = key;
          const id = self.id;
          const player = id.startsWith("p1") ? "player1" : "player2";
          const action = id.includes("Left") ? "left"
            : id.includes("Up") ? "up"
            : id.includes("Right") ? "right"
            : id.includes("Down") ? "down"
            : "jump";
  
          keyBindings[player][action] = key;
  
          updateInstructions();
          document.removeEventListener("keydown", listener);
        };
        document.addEventListener("keydown", listener);
      });
    });
  }
  
  function updateInstructions() {
    const p1 = keyBindings.player1;
    const p2 = keyBindings.player2;
    const p1Controls = document.querySelectorAll(".player-controls")[0];
    const p2Controls = document.querySelectorAll(".player-controls")[1];
  
    if (p1Controls) {
      p1Controls.querySelectorAll("p")[0].textContent =
        `${p1.left} = Gauche | ${p1.up} = Haut | ${p1.right} = Droite | ${p1.down} = Bas`;
      p1Controls.querySelectorAll("p")[1].textContent = `Saut: ${p1.jump}`;
    }
    if (p2Controls) {
      p2Controls.querySelectorAll("p")[0].textContent =
        `${p2.left} = Gauche | ${p2.up} = Haut | ${p2.right} = Droite | ${p2.down} = Bas`;
      p2Controls.querySelectorAll("p")[1].textContent = `Saut: ${p2.jump}`;
    }
  }
  function init() {
    canvas.width = 800;
    canvas.height = 590;
  
    initPlayers();
    initGrid();
    updateScoreHTML();
    const startBtn = document.getElementById("startBtn");
    if (startBtn) {
      startBtn.addEventListener("click", startGame);
    }

    const configBtn = document.getElementById("configBtn");
    if (configBtn) {
      configBtn.addEventListener("click", openConfigDialog);
    }
    setupConfigInputs();
    drawGrid();
    drawPlayers();
    if (typeof $ !== "undefined" && $.ui) {
      $("#configDialog").dialog({
        autoOpen: false,
        modal: true,
        width: 480,
        buttons: {
          "Fermer": function () { $(this).dialog("close"); }
        }
      });
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
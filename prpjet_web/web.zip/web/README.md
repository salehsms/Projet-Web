# SAE PROGRAMMATION Web 1 :Tron
## Binomes 
- SALEH Mahamat Saleh
- IGIRANEZA Amanda Leita

## Description
Ce projet est un jeu de course multijoueur développé en JavaScript avec un rendu graphique sur un canvas. Deux joueurs s'affrontent en controlant chacun un ruban qui se déplace sur une grille.Le but est
d'éviter les collisions et de marquer un certain nombre de points pour gagner la partie.

## Fonctionnalités
- Contrôle de deux joueurs simultanés avec des touches configurables
- Mouvements sur un grille (haut,bas,gauche,droite)et possibilité de sauter
- Gestion des collisions avec les murs et les traces laissées par les joueurs
- Affichage de la grille et des joueurs sur le canvas
- Système de score
- Interface de configuration des touches pour chaque joueur
- Gestion des parties et redemarrage d'une nouvelle partie

## Utilisation
- Cliquer sur le bouton Demarrer la partie pour lancer le jeu
- utiliser les touches suivants par défauts :
- On peut configurer les touches via le bouton de configuration
- Le but est d'éviter de rentrer en collision avec les murs ou les traces adverses et d'atteindre un score de 3 points pour gagner.
## Structure du Code
- initPlayers() : Initialise les joueurs avec leurs positions et   attributs.

- initGrid() : Crée la grille de jeu vide.
- drawGrid() : Dessine le fond noir de la grille.
- drawPlayers() : Dessine les joueurs et leurs traces.
- drawHead() : Dessine la tête du joueur (remplacé par un dessin de moto).
- handlePlayerInput() : Gère les entrées clavier des joueurs.
- gameTick() : Met à jour la logique de jeu à chaque intervalle.
- startGame(), startRound(), endRound(), endGame() : Contrôlent le déroulement du jeu.
- updateScoreHTML() : Met à jour l'affichage des scores.
- openConfigDialog(), setupConfigInputs(), updateInstructions() : Gèrent la configuration des touches.
## Commande des joueurs 
| Joueur | Gauche | Haut | Droite | Bas | Saut |
|--------|--------|------|--------|-----|------|
| P1 (Bleu) | Q | Z | D | W | A |
| P2 (Rouge) | O | M | ; | K | P |

##  Fichiers du projet

- [index.html](./index.html)
- [script.js](./javascript.js)
- [style.css](./style.css) 
## Apercu de la representation graphique du jeu
![tron](./image/tron.png)